public class Okrag {
    Punkt srodek;
    double promien;

    public Okrag(Punkt srodek, double promien) {
        this.srodek = srodek;
        this.promien = promien;
    }

}
