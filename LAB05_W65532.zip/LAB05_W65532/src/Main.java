public class Main {
    public static void main(String[] args) {
        Punkt pk1= new Punkt();
        Punkt pk2= new Punkt(3.0,1.5);
        Punkt pk3= new Punkt(4.0,-1.5);

        System.out.println("Pkt1: ");
        pk1.setX(3.4);
        pk1.setY(0.5);
        pk1.opis();
        pk1.przesun(1,1);
        pk1.opis();

        System.out.println("Pkt2: ");
        pk2.przesun(1,1);
        pk2.opis();

        System.out.println("Pkt3: ");
        pk3.przesun(1,1);
        pk3.opis();



    }
}